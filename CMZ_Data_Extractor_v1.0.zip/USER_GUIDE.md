# CMZ Data Extractor - User Guide

## Overview
CMZ Data Extractor is a Windows application for processing sales and purchases data from PDF and Excel files. It automatically extracts, processes, and organizes your business data into standardized formats.

## Quick Start

### 1. Launch the Application
Double-click `CMZ_Data_Extractor.exe` to start the application.

### 2. Select Your Data Directory
- Click "Browse..." next to "Data Files Directory"
- Select the folder containing your PDF and Excel files
- The folder should contain:
  - PDF files (Weekly Sales documents)
  - Excel files (Purchase/delicatessen files)

### 3. Configure Templates (Optional)
The application comes with default templates, but you can customize them:
- **Sales Template**: For processing PDF sales data
- **Purchases Template**: For processing Excel purchase data  
- **Upload Template**: For generating upload-ready CSV files

### 4. Choose Processing Options
Select what you want the application to generate:
- ✅ **Rename PDF files**: Creates standardized PDF names
- ✅ **Generate individual data files**: Creates JSON/CSV for each document
- ✅ **Generate combined CSV**: Merges all sales and purchases data
- ✅ **Generate upload CSV**: Creates upload-ready format

### 5. Process Your Data
Click the "Start" button to begin processing. The progress bar will show the current status.

## Output Files

The application creates an `output` folder in your selected directory with:

### Main Files
- `pdf_sales_data.csv` - All sales data in CSV format
- `purchases_data.csv` - All purchases data in CSV format
- `combined_sales_purchases.csv` - Unified sales and purchases data
- `upload_data.csv` - Data formatted for upload to accounting systems

### Organized Files
- `individual_json/` - Individual JSON files for each processed document
- `Renamed Invoices/` - PDF files with standardized names (Weekly Sales - Location WkXX)
- `weekly_sales_pdfs/` - Copies of all processed PDF files

## File Naming Conventions

### Input Files Expected
- **PDF Files**: Weekly sales documents (any naming format)
- **Excel Files**: Files containing "delicatessen" in the name

### Output Files Generated
- **Renamed PDFs**: `Weekly Sales - [Location] Wk[XX].pdf`
  - Example: `Weekly Sales - Tarxien Wk21.pdf`
- **Individual JSONs**: `[type]_[supplier]_[document]_[date].json`

## Supported Locations
- **Tarxien** (includes Carter/Carters)
- **Fgura**
- **Zabbar**

## Tips for Best Results

1. **Organize Input Files**: Keep all files in one main directory
2. **Check Templates**: Verify template files match your data structure
3. **Review Output**: Check the generated files in the output folder
4. **Week Numbers**: The system prioritizes PDF content over filenames for accuracy

## Troubleshooting

### Common Issues

**"No data was extracted"**
- Verify your files are in the correct format
- Check that PDF files contain readable text
- Ensure Excel files follow the expected structure

**"Template file not found"**  
- Make sure the `templates` folder is in the same directory as the executable
- Check that all template JSON files are present

**"Input directory does not exist"**
- Verify the selected directory path is correct
- Ensure you have read access to the directory

### Getting Help
- Check the console output for detailed error messages
- Verify your input files match the expected format
- Ensure all required templates are available

## Technical Requirements
- Windows 10 or later
- Sufficient disk space for output files
- Read/write permissions for selected directories

---

**Version**: 1.0  
**Built with**: Python, PyInstaller  
**Contact**: For support, refer to the project documentation
